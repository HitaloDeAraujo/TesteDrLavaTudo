﻿// Geração de código padrão desabilitada para o modelo 'C:\Users\usuario\Documents\Visual Studio 2012\Projects\TesteRestful\TesteRestful\Models\ModeloDeDados.edmx'. 
// Para habilitar a geração de código padrão, altere o valor da propriedade de designer 'Estratégia de Geração de Código'
// para um valor alternativo. Essa propriedade está disponível na Janela Propriedades quando o modelo estiver
// aberto no designer.